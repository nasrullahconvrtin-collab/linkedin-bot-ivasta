export const DEFAULTS = {
  backendUrl: 'http://localhost:8000',
  profileKey: '',
  extensionId: '',
  displayName: '',
  paired: false,
  paused: false,
  lastSync: '',
  lastError: '',
  currentJob: '',
  nextConnectionAllowedAt: 0,
  nextMessageAllowedAt: 0,
};

export async function getConfig() {
  return await chrome.storage.local.get(DEFAULTS);
}

export async function saveConfig(updates) {
  await chrome.storage.local.set(updates);
  return getConfig();
}

export async function clearConfig() {
  await chrome.storage.local.clear();
  return DEFAULTS;
}

export function extensionId() {
  const bytes = new Uint8Array(12);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}
